package com.corhuila.Parcial.IService;

import com.corhuila.Parcial.Entitity.Estudiante;

public interface IEstudianteService extends IBaseService<Estudiante>{

}
